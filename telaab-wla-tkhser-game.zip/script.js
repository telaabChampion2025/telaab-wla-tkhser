
function startGame() {
    alert("اللعبة بدأت!");
}
